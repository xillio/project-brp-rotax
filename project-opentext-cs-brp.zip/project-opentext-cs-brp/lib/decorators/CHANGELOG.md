# Decorators - Change Log
UDM standard decorators defined by Xillio

## [1.2] - 29-06-2016
### Change
- Remove gradle build files
- Restructure repository
- Rename repository
- Remove `getStandardDecorators()` and `newDecorator()`

## [1.1] - 01-06-2016
### Fix
- File decorator

## [1.0] - 30-06-2016
Initial release